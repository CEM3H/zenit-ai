"""
Module which contains tools for managing experiments
"""
