from setuptools import setup, find_packages



setup(
    name="zenitai",
    version="0.2",
    packages=find_packages(),
    descrption="A collection of tools and utils for data analysis. Contains functions and tools for WOE-transformations and other utils",
)


print(find_packages())
