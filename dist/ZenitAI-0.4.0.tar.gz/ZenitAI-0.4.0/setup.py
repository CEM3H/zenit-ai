from setuptools import setup, find_packages


setup(
    name="ZenitAI",
    version="0.4.0",
    packages=find_packages(),
    descrption="A collection of tools and utils for data analysis. Contains functions and tools for WOE-transformations and other utils",
)
